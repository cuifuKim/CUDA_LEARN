# FFT_and_NTT_optimization
Optimization Practice of NTT and FFT basic operators
An accelarated NTT, used in SEAL's Homomorphic Keygen, Encryption and Decryption operations.

This GPU implementation improve the performance of these three BFV operations by up to 141.95×, 105.17× and 90.13×, respectively, on Tesla v100 GPU compared to the highly-optimized SEAL library running on an Intel i9-7900X CPU.
